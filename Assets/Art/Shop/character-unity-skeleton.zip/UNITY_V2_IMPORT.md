# Unity 2D Animation V2 import

1. Unity 2022.3 LTS 프로젝트에 `2D Animation` 패키지 9.x를 설치합니다.
2. ZIP의 `Unity/Runtime`과 `UnityV2/Runtime`, `UnityV2/Editor`를 프로젝트의 `Assets` 아래에 복사합니다.
3. Unity 메뉴 `Tools > Sprite Lab > Import Rigging V2 ZIP`에서 이 ZIP을 선택합니다.
4. 생성된 `RiggingV2Avatar.prefab`에는 공유 전신 본, 각 파츠의 메시와 자동 웨이트, 눈·입 컨트롤이 들어 있습니다.
5. Sprite Editor의 Skinning Editor에서 본 위치와 웨이트를 캐릭터 자세에 맞게 보정합니다.

V2는 자동 리깅 초안입니다. 측면 자세, 겹친 팔다리, 무기와 긴 머리카락은 수동 보정이 필요합니다.
